Installation of ThermaCAM Connect 3 SR1
=======================================

	Introduction
	------------
	FLIR Systems� software ThermaCAM Connect 3 SR1 � lets you download images from your infrared camera to your desktop or laptop computer
	
	Installation
	------------

	Software Requirements
	---------------------		

		Camera
		------
		ThermaCAM Connect 3 SR1 will only work with these camera configurations:

		* E Series cameras: boot2 version 2.7.2.1 (or higher)
		* E Series cameras: appl  version 1.7.18.1 (or higher)
		* P/S cameras: boot2 version 2.4.2.1 (or higher)
		* P/S cameras: appl version 2.4.4.1 (or higher)

		To check the version of boot2, select Setup --> Camera Info in the camera. 
		Make sure the version number of the module �boot2� is as statesd above.

		Windows
		-------
		Serial communication (RS232) between PC and camera are supported on the following operating systems
		* Windows 98 Second Edition
		* Windows Me
		* Windows NT 4, Service Pack 6a
		* Windows 2000
		* Windows XP

		USB and FireWire connections between PC and camera are supported on the following operating systems
		* Windows 98 Second Edition
		* Windows Me
		* Windows 2000
		* Windows XP

		NOTE: Before you install the application, please close all other programs on the computer. 
		Make sure ThermaCAM Connect is installed before connecting the camera to the USB or FireWire port.


		Installing ThermaCAM Connect 3 SR1
		----------------------------------
		1. Make sure that the IR camera is switched off and that the cable between the IR camera and the computer is NOT connected.
		2. Insert the ThermaCAM Connect 3 SR1 installation CD into the CD-ROM drive.
		3. Select the preferred language and follow the on- screen instructions.


		NOTE: If the installation program doesn't start when you insert the installation CD, 
		please start the program manually by following the steps below.

		1. Double-click My Computer on the Desktop.
		2. Right-click on your CD-ROM drive and click Explore.
		3. Double-click SETUP.EXE
		4. Select the preferred language and follow the on-screen instructions.


		Installing USB and FireWire drivers
		-----------------------------------
		When the ThermaCAM Connect 3 SR1 installation is finished, you have to install the drivers 
		depending on how you connect the infrared camera to your computer.

		Before you continue with the installation, have your Windows installation CDs available.

		Make sure that the ThermaCAM Connect 3 SR1 installation CD is inserted into your CD-ROM drive.

		If you are using USB or FireWire communication, connect the camera to the computer and turn on the camera.

		Windows will now detect the new hardware.
		You find the appropriate installations procedure, covered on the following pages, matching your Window operating system and 
		communication standard (USB/FireWire).


		USB Driver Installation Procedure for Microsoft Windows XP
		----------------------------------------------------------
		1 When the system has detected the ThermaCAM, the Welcome to the Found New Hardware Wizard window appears. 
  		  The wizard asks; What do you want the wizard to do? 
  		  Select Install from a list or specific location

		2 Click Next

		3 The next wizard window is displayed; Please choose your search and installation options.
  		  Select Search for the best driver in these locations. 
  		  Uncheck Search removable media
  		  Check Include this location in the search
  		  Click Browse and locate folder "C:\Program Files\FLIR Systems\Device drivers"
  		  Click Ok

		4 Click Next

		5 The next wizard window is displayed; The driver has not passed Windows Logo testing to verify its compatibility with Windows XP.
  		  Click Continue Anyway

		6 The wizard copies the necessary driver files to your system.

		7 The first driver installation procedure is completed.
  		  Click finish.

		8 Reboot your computer if prompted to do so.

  
  
		USB Driver Installation Procedure for Microsoft Windows 2000
		------------------------------------------------------------
		1 When the system has detected the ThermaCAM, the Welcome to the Found New Hardware Wizard window appears.
  		  Click Next

		2 The next wizard window is displayed; This wizard will complete the installation for this device: FLIR USB Network Adapter. 
  		  The wizard asks; What do you want the wizard to do? 
  		  Select Search for a suitable driver for my device.

		3 Click Next

		4 The wizard asks; Where do you want Windows to search for driver files?
  		  Select Specify a location, uncheck all other options.

		5 Click Next 

		6 Click Browse and locate folder "C:\Program Files\FLIR Systems\Device drivers"
  		  Click Ok

		7 The wizard has now found a driver for the device.
  		  Click Next.

		8 The next wizard window is displayed; Microsoft has not digitally signed the driver.
  		  Click yes to continue 

		9 The wizard copies the necessary driver files to your system.

		10 The first driver installation procedure is completed.
   		   Click finish.



		USB Driver Installation Procedure for Microsoft Windows ME
		----------------------------------------------------------
		1 When the system has detected the ThermaCAM, the Windows has found the following new hardware: FLIR ThermaCAM.  
  		  What would you like to do? window appears.
  		  Select Specify the location of the driver.

		2 Click Next

		3 Select Search for the best driver for your device.
  		  Uncheck Removable media
  		  Check Specify a location
  		  Click Browse and locate folder "C:\Program Files\FLIR Systems\Device drivers"
  		  Click Ok

		4 Click Next

		5 Click Next

		6 If you get version conflict questions, Click Yes.

		7 Click Finish

		8 Reboot your computer if prompted to do so.



		USB Driver Installation Procedure for Microsoft Windows 98
		----------------------------------------------------------
		1 When the system has detected the ThermaCAM, the This wizard searches for new drivers for:  FLIR USB Network Adapter? window appears.
  		  Click Next

		2 The wizard asks; What do you want Windows to do?
  		  Select Search for the best driver for your device.

		3 Click Next

		4 Uncheck Floppy disk drives
  		  Uncheck CD-ROM drive
  		  Check Specify a location
  		  Click Browse and locate folder "C:\Program Files\FLIR Systems\Device drivers"
  		  Click Ok

		5 Click Next

		6 Click Next

		7 Insert Windows 98 CD-ROM if prompted to do so.

		8 Click Finish

		9 Reboot your computer if prompted to do so.



		FireWire/1394 Driver Installation Procedure for Microsoft Windows XP
		--------------------------------------------------------------------
		1 When the system has detected the ThermaCAM, the Welcome to the Found New Hardware Wizard window appears. 
  		  The wizard asks; What do you want the wizard to do? 
  		  Select Install from a list or specific location

		2 Click Next

		3 The next wizard window is displayed; Please choose your search and installation options.
  		  Select Search for the best driver in these locations. 
  		  Uncheck Search removable media
  		  Check Include this location in the search
  		  Click Browse and locate folder �C:\Program Files\FLIR Systems\Device drivers�
  		  Click Ok

		4 Click Next

		5 The next wizard window is displayed; 
		  The driver has not passed Windows Logo testing to verify its compatibility with Windows XP.
  		  Click Continue Anyway

		6 The wizard copies the necessary driver files to your system.

		7 The first driver installation procedure is completed.
  		  Click finish.

		8 Welcome to the Found New Hardware Wizard window appears again. 
  		  Repeat step 1 to 5. After that the driver installation is complete.

		9 Reboot your computer if prompted to do so



		FireWire/1394 Driver Installation Procedure for Microsoft Windows 2000
		----------------------------------------------------------------------
		1 When the system has detected the ThermaCAM, 
		  the Welcome to the Found New Hardware Wizard window appears.
  		  Click Next

		2 The next wizard window is displayed; This wizard will complete the installation 
                  for this device: FLIR 1394 Network Adapter. 
  		  The wizard asks; What do you want the wizard to do? 
  		  Select Search for a suitable driver for my device.

		3 Click Next

		4 The wizard asks; Where do you want Windows to search for driver files?
  		  Select Specify a location, uncheck all other options.

		5 Click Next

		6 Click Browse and locate folder �C:\Program Files\FLIR Systems\Device drivers�
  		  Click Ok

		7 The wizard has now found a driver for the device.
  		  Click Next.

		8 The next wizard window is displayed; Microsoft has not digitally signed the driver.
  		  Click yes to continue 

		9 The wizard copies the necessary driver files to your system.

		10 The first driver installation procedure is completed.
   		   Click finish.

		11 Welcome to the Found New Hardware Wizard window appears again.
   		   Repeat step 1 to 11. After that the driver installation is complete.



		FireWire/1394 Driver Installation Procedure for Microsoft Windows ME
		--------------------------------------------------------------------
		1 When the system has detected the ThermaCAM, the Windows has found the following 
                  new hardware: FLIR ThermaCAM_R3. What would you like to do? window appears.
  		  Select Specify the location of the driver.

		2 Click Next

		3 Select Search for the best driver for your device.
  		  Uncheck Removable media
  		  Check Specify a location
  		  Click Browse and locate folder �C:\Program Files\FLIR Systems\Device drivers�
  		  Click Ok

		4 Click Next

		5 Click Next

		6 If you get version conflict questions, Click Yes.

		7 Click Finish

		8 Windows has found the following new hardware: FLIR ThermaNET_R2 window appears.

		9 Repeat Step 1-4,6-7

		10 Reboot your computer if prompted to do so.



		FireWire/1394 Driver Installation Procedure for Microsoft Windows 98
		--------------------------------------------------------------------
		Windows 98 doesn�t support Plug and Play for FireWire. 
		After you have connected the camera follow the instructions below.

		1 Click Start-Settings-Control Panel in order to start the Control Panel 

		2 Double-click on Add New Hardware

		3 Click Next

		4 Click Next

		5 Select Yes, the device is in the list and select the FLIR ThermaCAM_R3 device.
  		  Click Next

		6 Click Finish

		7 Click Reinstall Driver

		8 Click Next

		9 Select Search for a better drive than the one your device is using now
  		  Click Next

		10 Check Specify a location. Uncheck all other options.

		11 Click Browse and select folder C:\Program Files\FLIR Systems\Device drivers
   		   Click Ok

		12 Click Next

		13 Click Next

		14 Insert Windows 98 CD-ROM if prompted to do so.

		15 If you get version conflict questions, Click Yes.

		16 Click Finish

		17 Click Close

		18 Repeat Step 1 to 17 for the FLIR ThermaCAM_R1 device.

		19 Reboot your computer if prompted to do so.

